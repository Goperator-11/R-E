import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8")
import collections
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import re

base = Path(r"C:\dev\codex_handoff\v33")
spec = importlib.util.spec_from_file_location("coverage_check", base / "tools/coverage_check.py")
coverage = importlib.util.module_from_spec(spec)
spec.loader.exec_module(coverage)
rows = coverage.index_rows()
assert len(rows) == 194 and len({fid for fid, _ in rows}) == 194
state = json.loads((base / "state/LOOP_STATE.json").read_text(encoding="utf-8"))
known = dict(rows)
events = collections.defaultdict(list)
inputs = []
for path in sorted((base / "runs").glob("*_coverage.md")):
    text = path.read_text(encoding="utf-8")
    inputs.append({"path":str(path), "sha256":hashlib.sha256(path.read_bytes()).hexdigest()})
    for line_number, line in enumerate(text.splitlines(), 1):
        match = re.match(r"\| ((?:A\d+(?:r1)?|Q)-[A-Z]?\d+)\b", line)
        if not match:
            continue
        fid = match.group(1)
        if fid not in known:
            raise ValueError(f"unknown audit id {fid}: {path}:{line_number}")
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        status = next((value for value in ("처리함", "처리 안 함", "다른 과제로 넘김") if cells[1].startswith(value)), None)
        if status is None:
            raise ValueError(f"missing tracking disposition: {path}:{line_number}")
        events[fid].append({"path":str(path), "line":line_number, "status":status, "text":line})
summary = collections.Counter()
details = []
for fid, mapped in rows:
    statuses = {item["status"] for item in events[fid]}
    disposition = next((value for value in ("처리함", "다른 과제로 넘김", "처리 안 함") if value in statuses), "아직 추적 기록 없음")
    summary[disposition] += 1
    tasks = sorted(set(coverage.TASK_ID.findall(mapped)))
    open_tasks = [task for task in tasks if state["tasks"].get(task, {}).get("status") != "done"]
    details.append({"id":fid, "rollup_disposition":disposition, "mapped_tasks":tasks, "open_mapped_tasks":open_tasks, "tracking_events":events[fid]})
assert sum(summary.values()) == 194
result = {
    "recorded_kst":datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(),
    "source_count":194,
    "counts":dict(summary),
    "with_tracking_events":sum(bool(row["tracking_events"]) for row in details),
    "with_open_mapped_tasks":sum(bool(row["open_mapped_tasks"]) for row in details),
    "note":"Counts describe recorded coverage dispositions, not completed fixes. When several tasks cover one item, precedence is handled record, deferred record, unhandled record, no record. Full events and unfinished mapped tasks remain visible. An A0 reproduction or W0 world implementation does not complete a later policy fix.",
    "inputs":inputs,
    "items":details,
}
destination = base / "runs" / sys.argv[1]
assert destination.parent == base / "runs" and destination.suffix == ".json"
with destination.open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps({key:value for key,value in result.items() if key not in ("items", "inputs")}, ensure_ascii=False, indent=2))
