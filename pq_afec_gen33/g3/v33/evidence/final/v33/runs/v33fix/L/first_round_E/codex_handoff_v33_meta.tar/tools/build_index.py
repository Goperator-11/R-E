import json
import os
import sys

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8")

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIND = os.path.join(BASE, "findings")

AUDITS = [
    ("A1", "audit-cost-model.json", "verify-A1.json", ""),
    ("A2", "audit-learning.json", None, ""),
    ("A2r1", "audit-learning.run1.json", None, "A2-"),
    ("A3", "audit-go-wire.json", None, ""),
    ("A4", "audit-gen2-foundation.json", None, ""),
    ("A5", "audit-measurement.json", None, ""),
    ("A6", "audit-code-infra.json", "verify-A6.json", ""),
    ("A6r1", "audit-code-infra.run1.json", None, "A6-"),
    ("A7", "audit-prior-art.json", "verify-A7.json", ""),
    ("A8", "audit-quicgo-source.json", None, ""),
]

TASKS = {
    "A1-01": "J1", "A1-02": "J5", "A1-03": "O2", "A1-04": "J6", "A1-05": "M3",
    "A1-06": "M2", "A1-07": "O1", "A1-08": "J3", "A1-09": "J4", "A1-10": "J2,O3",
    "A1-11": "M1(하지 않음: 검증자 doubtful, 보류 복호를 막음)", "A1-12": "L5,O4", "A1-13": "J8",
    "A1-14": "W0", "A1-15": "W0,J8", "A1-16": "O2",
    "A2-01": "L1", "A2-02": "L1,L3", "A2-03": "L4", "A2-04": "L3", "A2-05": "L3",
    "A2-06": "L2", "A2-07": "L2", "A2-08": "L1,O1", "A2-09": "L4", "A2-10": "L3",
    "A2-11": "L5", "A2-12": "L1,W0", "A2-13": "O3", "A2-14": "L6,O4", "A2-15": "R2",
    "A2-16": "W1", "A2-17": "J1,J2,J3",
    "A2r1-01": "L2", "A2r1-02": "L1", "A2r1-03": "L3", "A2r1-04": "L3", "A2r1-05": "L3,L4",
    "A2r1-06": "L1,L4,O1", "A2r1-07": "L4", "A2r1-08": "L3", "A2r1-09": "O1",
    "A2r1-10": "L5", "A2r1-11": "L1,O3", "A2r1-12": "L6", "A2r1-13": "R2",
    "A2r1-14": "W1", "A2r1-15": "L2",
    "A3-01": "J4,T6", "A3-02": "L1,T4", "A3-03": "T5", "A3-04": "S4", "A3-05": "J7",
    "A3-06": "J3,T6", "A3-07": "J8,O2", "A3-08": "T5", "A3-09": "T5", "A3-10": "O2,O4,J8",
    "A3-11": "X7,M4", "A3-12": "G1,G2,S3", "A3-13": "O3", "A3-14": "T5", "A3-15": "T4",
    "A4-01": "L5", "A4-02": "J7", "A4-03": "J6", "A4-04": "J8", "A4-05": "J2,J3",
    "A4-06": "O1", "A4-07": "L4", "A4-08": "J5", "A4-09": "O2",
    "A4-10": "R3(문서만, 선행을 RS 아닌 것으로 바꾸지 않음)", "A4-11": "A1",
    "A5-01": "T2,X4", "A5-02": "T3,X1", "A5-03": "R2", "A5-04": "R2", "A5-05": "R2",
    "A5-06": "R2,X6", "A5-07": "A0,T7", "A5-08": "O2,X2", "A5-09": "X5,W0",
    "A5-10": "T7,R2", "A5-11": "T7", "A5-12": "A1", "A5-13": "X7", "A5-14": "A1,R2",
    "A5-15": "T7", "A5-16": "X3,X6", "A5-17": "X6",
    "A6-01": "S2", "A6-02": "S1", "A6-03": "S4", "A6-04": "S1", "A6-05": "S3",
    "A6-06": "S5", "A6-07": "S2", "A6-08": "S5(새 러너만, gen-2는 그대로)",
    "A6-09": "S5", "A6-10": "T1", "A6-11": "A1", "A6-12": "R3,T7", "A6-13": "T7",
    "A6-14": "S5", "A6-15": "S5", "A6-16": "S5",
    "A6r1-01": "S1", "A6r1-02": "S1", "A6r1-03": "S2", "A6r1-04": "S4", "A6r1-05": "S3",
    "A6r1-06": "T7(선택지, 검증자 doubtful)", "A6r1-07": "S5", "A6r1-08": "S2",
    "A6r1-09": "S5", "A6r1-10": "T1", "A6r1-11": "A1", "A6r1-12": "S5", "A6r1-13": "S5",
    "A6r1-14": "S2", "A6r1-15": "T7", "A6r1-16": "R3", "A6r1-17": "S5",
    "A7-01": "T2,X4,A1", "A7-02": "L6", "A7-03": "L6,A1", "A7-04": "J8,X8",
    "A7-05": "A1,X1", "A7-06": "A1", "A7-07": "T3,X1", "A7-08": "T3,X1", "A7-09": "J8",
    "A7-10": "J8", "A7-11": "L1", "A7-12": "L4", "A7-13": "L2", "A7-14": "L3",
    "A7-15": "J5,W0", "A7-16": "L3(TS 넣지 않음)", "A7-17": "M1", "A7-18": "M4,A1",
    "A7-19": "X5", "A7-20": "M4", "A7-21": "A1,X7", "A7-22": "T7,X6",
    "A8-01": "T2,M4,X4", "A8-02": "M1", "A8-03": "J8,A1", "A8-04": "T5",
    "A8-05": "J7", "A8-06": "L5,J6", "A8-07": "O2,O3", "A8-08": "J1,J2,J3",
    "A8-09": "L1,T4", "A8-10": "J4", "A8-11": "J8,O4", "A8-12": "M4",
}

CLAUDE_CHECKED = {
    "A4-01": "Claude 직접 확인: H c12000 저널 관측 S 14,058~14,114 B로 bin_needed_s = 12, 유효 모형 cert 12000 = 11",
    "A5-07": "Claude 직접 확인: D_p11_2955_l0 g2auto 클라 parity_sent 4,532 대 서버 parities 8,579, g3auto 7,991 대 7,991",
    "A2-01": "교차 확인: A7-11(검증 PARTLY, 핵심 성립)",
    "A2-06": "교차 확인: A7-13(검증 CONFIRMED)",
    "A2r1-01": "교차 확인: A7-13(검증 CONFIRMED)",
    "A2r1-02": "교차 확인: A7-11(검증 PARTLY, 핵심 성립)",
    "A8-02": "교차 확인: A7-17(검증 PARTLY, 현실적 deadline으로 수치 정정), verify-A1 MISSED",
    "A8-01": "교차 확인: A7-01(검증 CONFIRMED), A5-01",
    "A3-01": "교차 확인: A1-09(검증 CONFIRMED)",
    "A8-10": "교차 확인: A1-09(검증 CONFIRMED)",
    "A4-08": "교차 확인: A1-02(검증 CONFIRMED)",
    "A4-03": "교차 확인: A1-04(검증 CONFIRMED)",
    "A8-05": "교차 확인: A4-02(같은 결론, 독립 감사)",
}


def cut(s, n):
    s = (s or "").replace("\n", " ").replace("|", "/")
    return s if len(s) <= n else s[:n] + "…"


def main():
    lines = ["# 감사 결과 색인", "",
             "모든 항목의 원문은 같은 폴더의 `audit-*.md`(본문), `verify-*.md`(검증)에 있다.",
             "검증 열: CONFIRMED·PARTLY·REFUTED·UNVERIFIABLE은 반박 검증자 판정이다. 검증자가 없던 갈래(A2·A3·A4·A5·A8)는 '미검증'이고, Claude가 직접 확인했거나 다른 갈래가 독립적으로 같은 결론을 낸 항목은 비고에 적었다.",
             "PARTLY는 반드시 검증 파일의 `CORRECTED` 문장을 정본으로 쓴다. proposal이 doubtful·harmful인 항목은 제안을 그대로 구현하지 않는다.",
             "A2r1-·A6r1-은 같은 갈래의 1차 실행 결과다(사용 한도로 다시 돌아 두 벌이 생김). 2차가 정본이고 1차는 보조 근거다.", "",
             "| ID | 심각도 | 제목 | 검증 | 제안 판정 | 과제 | 비고 |", "|---|---|---|---|---|---|---|"]
    missed_lines = ["", "## 검증자가 찾은 누락 항목", "",
                    "| ID | 심각도 | 제목 | 과제 |", "|---|---|---|---|"]
    missed_tasks = {
        "A1-M01": "X1,A1", "A1-M02": "M1", "A1-M03": "L1",
        "A6-M01": "S5,A0", "A6-M02": "J4,T4", "A6-M03": "T7", "A6-M04": "S1", "A6-M05": "S0,S2", "A6-M06": "S1",
        "A7-M01": "O1", "A7-M02": "X7,J8", "A7-M03": "A1,R1", "A7-M04": "W0",
    }
    for key, af, vf, prefix in AUDITS:
        a = json.load(open(os.path.join(FIND, af), encoding="utf-8"))
        vm = {}
        missed = []
        if vf:
            v = json.load(open(os.path.join(FIND, vf), encoding="utf-8"))
            vm = {x["id"]: x for x in v["verdicts"]}
            missed = v.get("missed", [])
        for f in a["findings"]:
            fid = f["id"]
            if prefix:
                fid = fid.replace(prefix, key + "-", 1)
            v = vm.get(f["id"])
            verdict = v["verdict"] if v else "미검증"
            pa = v.get("proposal_assessment", "") if v else ""
            note = CLAUDE_CHECKED.get(fid, "")
            lines.append("| %s | %s | %s | %s | %s | %s | %s |" % (
                fid, f["severity"], cut(f["title"], 80), verdict, pa,
                TASKS.get(fid, "?"), note))
        for i, m in enumerate(missed):
            mid = "%s-M%02d" % (key, i + 1)
            missed_lines.append("| %s | %s | %s | %s |" % (
                mid, m["severity"], cut(m["title"], 90), missed_tasks.get(mid, "?")))
    out = os.path.join(FIND, "FINDINGS_INDEX.md")
    with open(out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(lines + missed_lines) + "\n")
    unknown = [l for l in lines if l.endswith("| ? |  |") or "| ? |" in l]
    print("written", out, "rows", len(lines) - 8, "unmapped", len(unknown))
    for l in unknown:
        print(l[:120])


if __name__ == "__main__":
    main()
