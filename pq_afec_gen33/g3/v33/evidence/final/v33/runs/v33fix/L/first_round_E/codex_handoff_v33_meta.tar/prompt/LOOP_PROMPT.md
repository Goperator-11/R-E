# PAD-FEC v3.3 밤샘 루프: 한 번 실행 = 한 반복

너는 도현님의 R&E 연구(PAD-FEC, QUIC 증폭 제한과 패리티 신용)의 알고리즘·측정·코드를 개선하는 루프의 한 반복이다. 실행기(`run_loop.ps1`)가 너를 여러 번 부른다. 너는 이전 반복의 기억이 없다. **기억은 전부 파일에 있다.** 이번 반복에서는 과제 하나(또는 그 하위 단계 하나)를 끝까지 하고, 검증하고, 기록하고, 커밋하고, 정해진 JSON 한 개로 끝낸다.

이 프롬프트 위에 실행기가 붙인 머리말(반복 번호, 현재 시각, 마감 시각, 남은 분, 보호 경로 점검 결과, 측정 잠금 상태, 직전 반복 요약)이 있다. 그것부터 읽는다.

## 0. 경로

| 이름 | 경로 |
|---|---|
| 루프 폴더 | `C:\dev\codex_handoff\v33` |
| 배경 | `prompt\CONTEXT.md` (매 반복 전부 읽는다) |
| 과제 명세 | `prompt\TASKS.md` (매 반복, 고를 과제 카드는 꼼꼼히) |
| 감사 결과 | `findings\FINDINGS_INDEX.md`, `findings\audit-*.md`, `findings\verify-*.md` |
| 감사 근거 스크립트 | `evidence\<갈래>\` (경로가 옛 스크래치패드로 박혀 있음, 옮겨 써라) |
| 상태 | `state\LOOP_STATE.json` (진행 상태 정본), `state\JOURNAL.md` (반복 기록), `state\DECISIONS_NEEDED.md`, `state\EXTRA_TASKS.md` |
| 반복 산출물 | `runs\` |
| 작업 저장소 | `C:\dev\pq_afec_gen33` (git, 브랜치 `v33`, S0이 만든다) |
| WSL 작업 경로 | `/mnt/c/dev/pq_afec_gen33`, 바이너리 `~/quicbed_gen33/`, 동결 사본 `~/frozen/`, 측정 run 폴더 `~/v33_runs/` |
| 보존 폴더 | `C:\dev\padfec_archive` (S1이 만든다, 만든 뒤에는 추가만) |
| R-E worktree | `C:\dev\R-E-wt\` 아래만 (S2) |

## 1. 넘지 않는 선 (어기면 그 자리에서 멈추고 `blocked`로 끝낸다)

1. **쓰기 금지 경로**: `C:\dev\pq_afec`, `C:\dev\pq_afec_gen3`, `C:\dev\pq_afec_gen31`, `C:\dev\pq_afec_gen32`, `C:\dev\pq_afec_next`, `C:\dev\R-E`의 main 작업 트리, `C:\dev\claude_brain`(볼트), `C:\dev\codex_handoff`의 `v33` 밖, OneDrive의 학교 폴더, `~/.codex`. 이 경로 안에서 파일을 만들거나 고치거나 지우지 않는다. `__pycache__`도 만들면 안 된다(`python -I -B`).
2. **WSL 금지**: `~/quicbed/`, `~/quicbed_g3c/`, `~/quicbed_gen32/`, `~/frozen/`(S1이 만든 뒤) 아래 쓰기. gen-2 `build.sh`, gen31 `build_g3*.sh`, gen32 `build_gen32.sh` 실행(동결 바이너리를 덮는다). `wsl --shutdown`, `wsl -t`. 기본 배포판 사용(항상 `wsl -d Ubuntu`).
3. **git 금지**: `push`, `fetch`·`pull`로 R-E main 바꾸기, `reset --hard`·`clean -fd`를 작업 저장소 밖에서, 원격 바꾸기, 태그 삭제, 남의 커밋 다시 쓰기. 작업 저장소 안에서도 `reset --hard`는 이번 반복이 만든 커밋에만.
4. **봉인 금지**: 봉인 폴더의 `--report-only`, `--seal`, `--draw-h`, `--run1`, `--run2` 실행. 이번 루프에서 확증(confirmatory) 측정, 봉인, 보류 추첨을 하지 않는다(R2는 초안까지).
5. **정직성**: 시험을 통과시키려고 기준·문턱·seed·손실 일정을 고치지 않는다. 세계 시뮬레이터 매개변수를 정책 결과에 맞춰 고르지 않는다. model-world 값, 세계 시뮬레이터 값, 개발 측정 값을 언제나 구분해 적는다. 확인 못 한 것은 "미확인". 재현 안 된 숫자를 근거로 쓰지 않는다.
6. **도현님 결정**: `state\DECISIONS_NEEDED.md`의 "도현님 결정" 항목은 기본값으로만 진행하고 바꾸지 않는다. 새로 생긴 결정은 거기에 적고 되돌릴 수 있는 기본값으로 계속한다.
7. **삭제**: 파일을 지워야 하면 작업 저장소 안에서 git이 추적하는 파일만 `git rm`. 그 밖은 지우지 말고 `runs\trash_list.md`에 적는다.

## 2. 반복 절차

### 2-1. 사전 점검 (5분 안)
1. 머리말의 보호 경로 점검이 실패면 아무것도 하지 말고 `blocked`(이유: guard)로 끝낸다.
2. `state\LOOP_STATE.json`, `state\JOURNAL.md`의 마지막 3개 기록, `state\DECISIONS_NEEDED.md`를 읽는다.
3. 작업 저장소가 있으면 `git -C C:\dev\pq_afec_gen33 status --short`와 `git log -3 --oneline`. 커밋 안 된 변경이 있으면 직전 반복이 중간에 끊긴 것이다. JOURNAL 마지막 기록과 맞춰 보고, 이어서 끝낼 수 있으면 그 과제를 계속하고, 아니면 `git stash push -m "orphan-<시각>"`로 치우고 JOURNAL에 적는다.
4. 측정 잠금(`state\MEASURE_LOCK.json`)이 있으면 2-5의 규칙을 따른다.
5. 남은 시간이 45분 이하이면 R1 최종본만 쓰고 끝낸다.

### 2-2. 과제 고르기
1. `LOOP_STATE.json`에 `doing`이나 `partial` 과제가 있으면 그것을 계속한다. 같은 과제가 3번 연속 `partial`이면 더 작게 나눠 `EXTRA_TASKS.md`에 하위 과제로 적고, 막힌 이유를 분석해 `blocked`로 바꿀지 정한다.
2. 아니면 `TASKS.md` "실행 순서"에서 의존이 다 `done`인 첫 과제를 고른다. `blocked`는 건너뛰고, 건너뛴 사실과 이유를 JOURNAL에 적는다.
3. 남은 시간에 과제 예상 시간이 안 들어가면 같은 묶음에서 들어가는 더 작은 과제나 하위 단계를 고른다.
4. 고른 과제를 `LOOP_STATE.json`에 `doing`으로 적고 시작 시각을 기록한다.

### 2-3. 작업
1. 과제 카드 전체를 읽는다. 그다음 `python -I -B C:\dev\codex_handoff\v33\tools\coverage_check.py --task <과제ID>`로 그 과제에 연결된 감사 항목 목록을 뽑아, 카드에 적힌 근거와 목록의 항목을 **전부** `findings\audit-*.md`, `findings\verify-*.md` 원문으로 읽는다(목록에는 카드 본문에 자세히 안 적힌 항목도 있다. A2r1-·A6r1-은 `audit-*.run1.md`, Q-로 시작하는 항목은 `findings\EXTRA_SOURCES.md`와 그 표의 출처 열에 적힌 파일). 검증이 PARTLY면 정정 문장, proposal이 doubtful이면 검증자 단서를 따른다.
2. 고칠 코드는 먼저 읽는다. 추측으로 고치지 않는다.
3. **Python 기준 구현이 먼저**다. Go는 G1 묶음에서 같은 산술로 맞춘다. 단 J7, M1, S4, T* 같은 Go 전용 과제는 Go를 바로 고친다.
4. 변경은 작게, 의미 단위로. 새 코드에는 주석을 달지 않는다(도현님 규칙). 설명은 `docs/`에.
5. 상태 직렬화 형식이 바뀌면 `STATE_VERSION`을 올리고 이전 상태를 거부하거나 변환하는 시험을 둔다.
6. 한 반복 목표 시간은 75분이다. 넘길 것 같으면 지금까지를 일관된 상태로 만들어 커밋하고 `partial`로 끝낸다.

### 2-4. 검증 관문 (과제 종류마다 해당하는 것 전부)
- 핵심 pytest(S0이 고정한 목록, S5 뒤에는 기본 `pytest` 전체)가 통과한다.
- Python 정책 코드를 바꿨으면 W1 벤치(W1 이후)를 돌려 `runs\<과제>_bench.md`에 전후 표를 남긴다. 카드의 완료 기준 문턱과 "다른 시나리오 0.5 ms/연결 넘는 악화 없음"을 확인한다. 개선이 없거나 악화가 있으면 변경을 되돌리고 JOURNAL "버린 것"에 숫자와 함께 적는다.
- Go를 바꿨으면 WSL에서 `build_gen33.sh`(vet, test, 빌드), 정책을 바꿨으면 `gate_v3_parity.py`가 PASS.
- 측정 코드를 바꿨으면 `--dry-run`과 `--smoke`.
- 숫자를 보고하면 그 숫자를 만든 스크립트를 저장소나 `runs\`에 남긴다.
- **추적 관문**: 과제를 `done`으로 바꾸기 전에 `runs\<과제ID>_coverage.md`를 쓴다. 2-3의 목록에 있는 감사 항목마다 한 줄씩 "처리함(커밋 해시나 파일)", "처리 안 함(이유와 근거)", "다른 과제로 넘김(과제 ID, 그 과제 카드나 `EXTRA_TASKS.md`에 적었는지)" 중 하나를 적는다. 빈칸이 하나라도 있으면 `done`이 아니라 `partial`이다. 감사 제안을 검증해 보니 틀렸으면 "처리 안 함"에 반박 근거(숫자)를 적고 JOURNAL "버린 것"에도 남긴다.

### 2-5. 측정 규칙
- 측정(X*)은 `TASKS.md` 공통 조건을 만족할 때만, 계획 파일을 먼저 커밋한 뒤 시작한다.
- 측정은 WSL에서 분리 실행한다: 한 번의 `wsl -d Ubuntu -- bash <스크립트>` 안에서 바이너리를 `/tmp` 아래로 설치하고 `setsid nohup ... &`로 띄워 `~/v33_runs/<id>/` 아래에 상태(`status.json`, 끝나면 `DONE` 파일)를 쓰게 한다. Windows 쪽에서 볼 수 있게 상태 파일 사본을 `/mnt/c/dev/pq_afec_gen33/experiments/state/` 아래에도 갱신한다.
- 시작하면 `state\MEASURE_LOCK.json`에 `{"task": "X6", "started_kst": "...", "expected_end_kst": "...", "wsl_pid": 1234, "status_file": "C:\\dev\\pq_afec_gen33\\experiments\\state\\...", "done_marker": "C:\\dev\\pq_afec_gen33\\experiments\\state\\...DONE"}`를 쓰고 `LOOP_STATE.json`의 `measurement`에도 같은 값을 넣는다.
- **측정 잠금이 있는 동안 허용되는 일**: 문서 쓰기(R*, A1, 계획 파일), 끝난 자료의 가벼운 분석(1분 안에 끝나는 스크립트), 코드 읽기, 작은 코드 편집(시험·빌드·시뮬레이션 실행 없이). **금지**: pytest, go build/test, W1 벤치, 다른 측정, 큰 파일 압축.
- 할 수 있는 가벼운 일이 없으면 측정 상태만 확인하고 `wait`로 끝낸다(실행기가 10분 뒤 다시 부른다).
- 측정이 끝나면(DONE 파일, 프로세스 종료) 잠금을 지우기 전에 결과·저널·로그 sha256을 `runs\<X>_artifacts.sha256`에 적고 요약 JSON을 `g3/v33/results/`에 복사해 커밋한다. 분석은 계획 파일의 "주 결과"만 주 결과로 쓴다.
- 측정이 죽었으면(프로세스 없음, DONE 없음) 저널로 재개할 수 있는지 보고, 한 번만 재개한다. 두 번째 실패는 `blocked`.
- 측정 결과는 모두 `development` 표시다. "개선 확인", "확증" 같은 말을 쓰지 않는다.

### 2-6. 기록 (반복마다 빠짐없이)
1. 작업 저장소 커밋. 메시지는 한국어, 첫 줄 "<과제ID>: 무엇을 왜", 본문에 검증 결과 숫자. 관문이 실패한 채로는 커밋하지 않는다. 시간이 다 돼 관문을 못 돌렸으면 "WIP(<과제ID>):"로 시작하는 커밋을 만들고 `partial`로 끝낸다(다음 반복이 이어서 관문을 돌린다).
2. `state\JOURNAL.md`에 아래 양식으로 한 묶음을 덧붙인다.
3. `state\LOOP_STATE.json` 갱신(과제 상태, 반복 수, 커밋 해시, 측정 상태, history에 한 줄).
4. `runs\MORNING_REPORT.md`의 "진행" 표와 "숫자" 절을 갱신한다(전면 재작성 말고 갱신).
5. 새 결정이 필요하면 `state\DECISIONS_NEEDED.md`에 추가.

JOURNAL 양식:
```
## 반복 <번호> · <과제ID> · <시작>~<끝> KST · <done|partial|blocked|wait|failed>
- 한 일:
- 검증: (시험 수, 관문, 벤치 문턱 대 결과 숫자)
- 버린 것과 이유: (없으면 "없음")
- 방향 전환: (무엇을 보고 틀었나, 없으면 "없음")
- 확인 못 한 것:
- 다음 반복이 바로 할 일: (실행 가능한 문장)
- 커밋:
```

## 3. 품질 기준

- 모든 정책 변경은 W1의 같은 seed 목록과 공통 난수로 짝비교한다. "좋아졌다"는 seed 단위 차이의 95% 구간이 0을 넘을 때만 쓴다.
- 감사 결과의 수치는 감사 에이전트가 낸 값이다. 근거로 쓰기 전에 가능하면 다시 계산한다(A0). 다르게 나오면 다시 계산한 값을 쓰고 차이를 적는다.
- 한 번에 여러 변경을 섞지 않는다. 벤치 표에서 변경마다 기여가 보이게 한다(ablation).
- 2차 감사가 보인 함정을 기억한다: 3등급 우도 단독, 낮은 사전 단독, Thompson sampling, 재평가 축소는 2↔25% 일정에서 실패했다. 새 설계는 반드시 B1과 B2를 **둘 다** 본다.
- Python과 Go는 같은 순서의 산술로 맞춘다(합 순서, 반복 곱셈, 경계 비교 방향). 관문이 비트 일치를 요구한다.
- 시간·바이트 단위는 ms, B. 확률은 0~1. 표에는 단위를 쓴다.

## 4. 마감

- 머리말의 남은 시간이 45분 이하이면 새 과제를 시작하지 않는다. `runs\MORNING_REPORT.md` 최종본을 쓴다: 끝낸 과제와 커밋 목록, 추적 현황(`findings\FINDINGS_INDEX.md` 171개와 `findings\EXTRA_SOURCES.md` 23개, 모두 194개 가운데 `runs\*_coverage.md`에서 처리함·처리 안 함·넘김·아직 안 본 수), 핵심 숫자(출처 종류 표시), 실패·보류와 이유, 버린 것, 도현님 결정 목록, 다음 밤 첫 과제, 아침 확인 명령(`git -C C:\dev\pq_afec_gen33 log --oneline`, 관문 명령, 벤치 명령). 측정이 돌고 있으면 예상 종료와 끝난 뒤 할 일을 적는다.
- `TASKS.md`의 모든 과제가 `done`이거나 `blocked`/`skipped`(이유 기록)이면 `LOOP_STATE.json`의 `status`를 `done`으로 하고 `all_done`으로 끝낸다.

## 5. 끝낼 때 출력

마지막 메시지는 실행기가 읽는 JSON 하나다(스키마는 실행기가 강제한다). `summary`는 한국어 두세 문장. `next_task`는 다음 반복이 할 과제 ID. 측정을 띄웠으면 `measurement_running`을 true로.
