import json
import os
import sys

sys.dont_write_bytecode = True

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

ORDER = ["S0", "S1", "S3", "A0", "W0", "W1", "L1", "L2", "L3", "L4", "J1", "J2", "J6", "L5",
         "J7", "M1", "G1", "G2", "S4", "T1", "T4", "T5", "T6", "T7", "X6", "T3", "X1", "T2",
         "X4", "O2", "X2", "X3", "X9", "J5", "O3", "O4", "L6", "O1", "J3", "J4", "M4", "M2", "M3",
         "J8", "X5", "X7", "X8", "S2", "S5", "A1", "R3", "R2", "R1"]

DEPENDS = {
    "S0": [], "S1": [], "S3": ["S0"], "A0": ["S0"], "W0": ["A0"], "W1": ["W0"],
    "L1": ["W1"], "L2": ["L1"], "L3": ["L1"], "L4": ["L3"], "J1": ["W1"], "J2": ["J1"],
    "J6": ["W1"], "L5": ["W1"], "J7": ["S0"], "M1": ["W1"],
    "G1": ["L1", "L2", "L3", "L4", "J1", "J2", "J6", "L5", "J7"], "G2": ["M1", "G1"],
    "S4": ["S3"], "T1": ["S4"], "T4": ["S4"], "T5": ["S4"], "T6": ["S4"],
    "T7": ["G1", "G2", "S4", "T1", "T4"], "X6": ["T7"], "T3": ["S4"], "X1": ["T7", "T3"],
    "T2": ["S4"], "X4": ["T7", "T2"], "O2": ["W1"], "X2": ["T7", "O2"], "X3": ["T7"], "X9": ["T7", "T4"],
    "J5": ["W1"], "O3": ["W1"], "O4": ["S4"], "L6": ["L5"], "O1": ["L4"], "J3": ["T6"],
    "J4": ["J1"], "M4": ["T2"], "M2": ["M1", "J5"], "M3": ["O1"], "J8": ["W1"],
    "X5": ["T7"], "X7": ["T7"], "X8": ["T7"], "S2": [], "S5": ["S3"], "A1": ["A0"],
    "R3": ["G1"], "R2": ["A1"], "R1": [],
}

OPTIONAL = {"X7", "X8"}


def main():
    path = os.path.join(BASE, "state", "LOOP_STATE.json")
    if os.path.exists(path) and "--force" not in sys.argv:
        print("exists, use --force:", path)
        return
    tasks = {t: {"status": "todo", "iterations": 0, "commits": [], "note": "",
                 "depends": DEPENDS[t], "optional": t in OPTIONAL} for t in ORDER}
    state = {
        "version": 1,
        "status": "running",
        "created_by": "Claude 2026-10-30",
        "order": ORDER,
        "current": None,
        "tasks": tasks,
        "measurement": None,
        "iterations": 0,
        "history": [],
        "note": "과제 상태 값: todo, doing, partial, done, blocked, skipped. G1 이후에 바뀌는 Python 정책 코드는 그 과제 안에서 Go 거울과 관문까지 끝낸다.",
    }
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(state, f, ensure_ascii=False, indent=1)
    print("written", path, len(ORDER), "tasks")


if __name__ == "__main__":
    main()
