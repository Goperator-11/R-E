# PAD-FEC v3.3 밤샘 루프

2026-10-29~30 종합 감사 결과 전부를 Codex가 밤새 이어서 처리하도록 만든 루프다. Codex는 이 대화를 모른다. 그래서 감사 결과, 근거 스크립트, 배경 사실, 과제 명세, 상태를 모두 이 폴더에 파일로 두었다. 실행기는 Codex를 한 반복씩 새로 부르고, Codex는 매번 파일에서 상태를 읽어 과제 하나를 끝내고 기록한 뒤 끝난다.

## 시작

충전기를 꽂는다. 덮개는 닫아도 된다. 시작 메뉴의 전원 메뉴는 쓰지 않는다(측정이 죽는다).

```powershell
pwsh -NoProfile -File C:\dev\codex_handoff\v33\run_loop.ps1
```

기본 마감은 다음 09:00 KST다(새벽 6시 전에 시작하면 그날 09:00). 바꾸려면 `-Deadline '2026-10-30 10:30'`. 그 밖의 옵션은 반복 상한 `-MaxIter 80`, 반복 시간 상한 `-IterTimeoutMin 150`, 모델 `-Model`, 추론 강도 `-Effort`(비우면 `~/.codex/config.toml` 값), 건식 점검 `-DryRun`이다. Windows PowerShell 5.1이 아니라 `pwsh`(7)로 돌린다.

실행기가 하는 일:
1. 절전 막기(`tools/wakehold_v33.py`, 실행기가 끝나거나 마감이 되면 풀린다).
2. 반복마다 보호 경로 점검(`tools/guard_check.py`). gen-2·v3.0·v3.1·v3.2·next 폴더, R-E main 작업 트리, WSL의 봉인·동결 바이너리 5개가 바뀌면 `STOP` 파일을 만들고 멈춘다. 첫 실행 때 기준선을 만든다.
3. 머리말(시각, 남은 시간, 점검 결과, 측정 잠금, 직전 반복 요약)을 `prompt/LOOP_PROMPT.md` 앞에 붙여 `runs/iterNNN_prompt.md`로 쓰고 `codex exec`를 부른다. Codex의 마지막 출력은 `prompt/iter_schema.json` 형식 JSON으로 강제된다.
4. 사용 한도에 걸리면 풀리는 시각까지(못 읽으면 30분) 기다렸다가 같은 반복을 다시 한다. 마감 전에 안 풀리면 끝낸다.
5. 측정 대기(`wait`)면 10분 쉬고, 막힘 3번 연속이나 실패 3번 연속이면 멈춘다.

## 지켜보기

| 파일 | 내용 |
|---|---|
| `state/runner.log` | 실행기 기록 |
| `runs/runs.log` | 반복마다 한 줄(상태, 과제, 걸린 분) |
| `state/JOURNAL.md` | Codex의 반복 기록(한 일, 검증 숫자, 버린 것, 다음 할 일) |
| `runs/MORNING_REPORT.md` | 아침 보고서(마감 45분 전에 최종본) |
| `state/LOOP_STATE.json` | 과제 53개의 상태 |
| `state/DECISIONS_NEEDED.md` | 도현님이 정할 것(루프는 기본값으로만 진행) |
| `runs/iterNNN.jsonl`, `_stderr.txt` | Codex 원기록 |

## 멈추기와 다시 시작

- 지금 반복이 끝나면 멈추기: `New-Item C:\dev\codex_handoff\v33\STOP`
- 당장 멈추기: 실행기 창을 닫는다(돌던 측정은 WSL에서 계속 돈다. 측정 잠금 파일을 보고 판단).
- 다시 시작(다음 밤 포함): `STOP`을 지우고 같은 명령. 상태는 파일에 있으므로 이어서 간다.
- 보호 폴더를 일부러 바꿨다면(예: 도현님이 gen-2를 고침) `state/guard_baseline.json`을 지워야 새 기준선을 잡는다.

## 폴더

| 경로 | 내용 |
|---|---|
| `prompt/LOOP_PROMPT.md` | 매 반복의 계약(절차, 넘지 않는 선, 측정 규칙, 기록 양식) |
| `prompt/CONTEXT.md` | 배경 사실(세대, 테스트베드 함정, 측정 결과, 감사 결론, 하지 말 것) |
| `prompt/TASKS.md` | 과제 53개 명세(근거 ID, 할 일, 완료 기준, 하지 말 것) |
| `findings/` | 감사 8갈래 원문, 검증 3갈래, 색인 `FINDINGS_INDEX.md`(감사 항목 159개와 검증자가 찾은 누락 12개, 모두 171개마다 검증 상태와 과제 번호), 감사 밖 수정 거리 `EXTRA_SOURCES.md`(팀 문서·볼트에서 뽑은 23개) |
| `evidence/` | 감사 에이전트가 쓴 스크립트와 출력(16 MB) |
| `tools/` | 보호 점검, 절전 막기, 색인·상태 생성기, 추적 점검 `coverage_check.py`(전체 점검, `--task <ID>`로 과제별 감사 항목 목록) |
| `KICK.md` | Codex 앱에서 손으로 한 반복씩 돌릴 때 붙여 넣는 문구 |

## 기본으로 정해 둔 것 (`state/DECISIONS_NEEDED.md`)

push 안 함, GitHub Release 업로드 안 함, 확증 측정·봉인 안 함(초안까지), 비교 기준 gen-2는 동결 바이너리, `pq_afec_next`는 보관 브랜치만, 새 외부 소스 내려받기 안 함, 볼트는 루프가 쓰지 않음.

## 위험과 한계

- Codex는 `danger-full-access`로 돈다(WSL 측정, git, 여러 폴더 쓰기에 필요). 넘지 않는 선은 프롬프트 규칙이고, 보호 점검은 **사후에** 잡는다(막지는 못한다). 가장 잃기 아까운 v3.1 원자료는 두 번째 과제(S1)에서 `C:\dev\padfec_archive`로 먼저 복사한다. 걱정되면 첫 실행 전에 그 복사를 손으로 해 두어도 된다.
- 과제는 53개이고 한 밤에 다 끝나지 않는다. 첫 밤은 준비(S0, S1, S3), 근거 재현(A0), 세계 시뮬레이터(W0, W1), 학습층(L1~L4) 근처까지가 현실적이다. 측정(X*)은 Go 거울과 측정 러너(G1, T7)가 끝난 뒤라 둘째 밤 이후다.
- 감사 수치 가운데 검증자가 확인하지 못한 갈래(A2·A3·A4·A5·A8)가 있다. 그래서 A0에서 핵심 숫자를 먼저 다시 계산하게 했다.

## 아침에

Claude에게 "루프 결과 정리해줘"라고 하면 `state/JOURNAL.md`, `runs/MORNING_REPORT.md`, 작업 저장소 커밋을 읽고 확인한 뒤 볼트에 기록한다.
