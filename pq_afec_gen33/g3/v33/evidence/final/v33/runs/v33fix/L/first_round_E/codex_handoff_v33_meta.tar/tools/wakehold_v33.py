import ctypes
import datetime as dt
import os
import sys
import time

sys.dont_write_bytecode = True

ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001
KST = dt.timezone(dt.timedelta(hours=9))
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG = os.path.join(BASE, "state", "runner.log")
STOP = os.path.join(BASE, "STOP")


def log(msg):
    with open(LOG, "a", encoding="utf-8") as f:
        f.write("%s  [wakehold] %s\n" % (dt.datetime.now(KST).strftime("%m-%d %H:%M:%S"), msg))


def alive(pid):
    if pid <= 0:
        return True
    h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
    if not h:
        return False
    code = ctypes.c_ulong()
    ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
    ctypes.windll.kernel32.CloseHandle(h)
    return code.value == 259


def main():
    until = dt.datetime.fromisoformat(sys.argv[1])
    if until.tzinfo is None:
        until = until.replace(tzinfo=KST)
    pid = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    log("시작 pid=%d 실행기 pid=%d %s까지 절전 막기" % (os.getpid(), pid, until.strftime("%m-%d %H:%M")))
    while dt.datetime.now(KST) < until and not os.path.exists(STOP) and alive(pid):
        ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED)
        time.sleep(30)
    ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
    log("끝")


if __name__ == "__main__":
    main()
