﻿param(
    [string]$Deadline = '',
    [int]$MaxIter = 80,
    [int]$IterTimeoutMin = 150,
    [int]$IdleSleepMin = 10,
    [string]$Sandbox = 'danger-full-access',
    [string]$Model = '',
    [string]$Effort = '',
    [switch]$DryRun,
    [switch]$NoWakeHold
)

$ErrorActionPreference = 'Continue'
$Base = 'C:\dev\codex_handoff\v33'
$State = Join-Path $Base 'state'
$Runs = Join-Path $Base 'runs'
$Repo = 'C:\dev\pq_afec_gen33'
$Py = 'C:\Users\scien\AppData\Local\Programs\Python\Python314\python.exe'
$Guard = Join-Path $Base 'tools\guard_check.py'
$Schema = Join-Path $Base 'prompt\iter_schema.json'
$LoopPrompt = Join-Path $Base 'prompt\LOOP_PROMPT.md'
$StopFile = Join-Path $Base 'STOP'
$LockFile = Join-Path $State 'MEASURE_LOCK.json'
$StateFile = Join-Path $State 'LOOP_STATE.json'
$RunnerLog = Join-Path $State 'runner.log'
$RunsLog = Join-Path $Runs 'runs.log'
$Empty = Join-Path $Runs 'empty_stdin.txt'
$Kst = [System.TimeZoneInfo]::FindSystemTimeZoneById('Korea Standard Time')

function Now-Kst { [System.TimeZoneInfo]::ConvertTimeFromUtc([DateTime]::UtcNow, $Kst) }

function Write-Log([string]$Msg) {
    $line = '{0}  {1}' -f (Now-Kst).ToString('MM-dd HH:mm:ss'), $Msg
    Add-Content -Path $RunnerLog -Value $line -Encoding utf8
    Write-Host $line
}

function Quote-Arg([string]$a) {
    if ($a -match '[\s"]') { return '"' + ($a -replace '"', '\"') + '"' }
    return $a
}

function Invoke-Guard {
    $out = & $Py -I -B $Guard --check 2>&1 | Out-String
    $rc = $LASTEXITCODE
    if ($rc -eq 3) {
        Write-Log '보호 경로 기준선이 없어 새로 만든다'
        & $Py -I -B $Guard --init 2>&1 | Out-String | ForEach-Object { Write-Log $_.Trim() }
        $out = & $Py -I -B $Guard --check 2>&1 | Out-String
        $rc = $LASTEXITCODE
    }
    return @{ rc = $rc; text = $out.Trim() }
}

function Find-Codex {
    $c = Get-ChildItem -Path (Join-Path $env:LOCALAPPDATA 'OpenAI\Codex\bin\*\codex.exe') -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($null -eq $c) { return $null }
    return $c.FullName
}

New-Item -ItemType Directory -Force $Runs | Out-Null
New-Item -ItemType Directory -Force $State | Out-Null
if (-not (Test-Path $Empty)) { Set-Content -Path $Empty -Value '' -Encoding utf8 -NoNewline }

if ([string]::IsNullOrWhiteSpace($Deadline)) {
    $now = Now-Kst
    $DeadlineKst = $now.Date.AddHours(9)
    if ($now.Hour -ge 6) { $DeadlineKst = $DeadlineKst.AddDays(1) }
} else {
    $DeadlineKst = [DateTime]::ParseExact($Deadline, 'yyyy-MM-dd HH:mm', [Globalization.CultureInfo]::InvariantCulture)
}

$Cx = Find-Codex
if (-not $Cx) { Write-Log 'codex.exe를 찾지 못했다. Codex 앱이 설치돼 있는지 확인'; exit 2 }
Write-Log ('실행기 시작 pid={0} 마감 {1} codex {2} sandbox {3} 반복 상한 {4} 반복 시간 상한 {5}분 DryRun={6}' -f $PID, $DeadlineKst.ToString('yyyy-MM-dd HH:mm'), $Cx, $Sandbox, $MaxIter, $IterTimeoutMin, [bool]$DryRun)

if ((Test-Path $StopFile) -and -not $DryRun) { Write-Log "STOP 파일이 있다($StopFile). 지우고 다시 실행"; exit 1 }

if (-not $NoWakeHold -and -not $DryRun) {
    $iso = $DeadlineKst.ToString('yyyy-MM-ddTHH:mm:ss') + '+09:00'
    Start-Process -FilePath $Py -ArgumentList @('-I', '-B', (Quote-Arg (Join-Path $Base 'tools\wakehold_v33.py')), $iso, "$PID") -WindowStyle Hidden | Out-Null
    Write-Log '절전 막기 시작'
}

$existing = Get-ChildItem -Path $Runs -Filter 'iter*_prompt.md' -ErrorAction SilentlyContinue |
    ForEach-Object { [int]($_.BaseName -replace '^iter(\d+)_prompt$', '$1') } | Sort-Object -Descending | Select-Object -First 1
$n = if ($existing) { $existing } else { 0 }
$calls = 0
$failStreak = 0
$blockStreak = 0
$lastSummary = '(이번 실행의 첫 반복)'
$prevLast = Get-ChildItem -Path $Runs -Filter 'iter*_last.json' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
if ($prevLast) {
    try {
        $pj = Get-Content $prevLast.FullName -Raw -Encoding utf8 | ConvertFrom-Json
        $lastSummary = '{0}: status={1} task={2} next={3} | {4}' -f $prevLast.BaseName, $pj.status, $pj.task_id, $pj.next_task, $pj.summary
    } catch { }
}

while ($calls -lt $MaxIter) {
    if (Test-Path $StopFile) { Write-Log 'STOP 파일을 보고 멈춘다'; break }
    $now = Now-Kst
    $left = [int]($DeadlineKst - $now).TotalMinutes
    if ($left -le 5) { Write-Log '마감 도달'; break }

    if (Test-Path $StateFile) {
        try {
            $st = Get-Content $StateFile -Raw -Encoding utf8 | ConvertFrom-Json
            if ($st.status -eq 'done') { Write-Log 'LOOP_STATE status=done. 모든 과제 끝'; break }
        } catch { Write-Log "LOOP_STATE.json을 읽지 못했다: $($_.Exception.Message)" }
    }

    $g = Invoke-Guard
    if ($g.rc -eq 2) {
        Write-Log "보호 경로 위반. 루프를 멈춘다`n$($g.text)"
        Set-Content -Path $StopFile -Value ("guard fail " + (Now-Kst).ToString('s')) -Encoding utf8
        break
    }

    $lockText = '없음'
    if (Test-Path $LockFile) { $lockText = (Get-Content $LockFile -Raw -Encoding utf8).Trim() }

    $n += 1
    $calls += 1
    $stamp = 'iter{0:D3}' -f $n
    $promptFile = Join-Path $Runs "${stamp}_prompt.md"
    $lastFile = Join-Path $Runs "${stamp}_last.json"
    $jsonl = Join-Path $Runs "${stamp}.jsonl"
    $errFile = Join-Path $Runs "${stamp}_stderr.txt"

    $header = @"
# 실행기 머리말

- 반복 번호: $n (이번 실행의 $calls 번째 호출)
- 지금: $($now.ToString('yyyy-MM-dd HH:mm')) KST
- 마감: $($DeadlineKst.ToString('yyyy-MM-dd HH:mm')) KST, 남은 시간 $left 분
- 반복 시간 상한: $IterTimeoutMin 분(넘으면 실행기가 강제로 끝낸다. 목표는 75분)
- 보호 경로 점검: $($g.text -replace "`r?`n", ' / ')
- 측정 잠금: $lockText
- 직전 반복: $lastSummary
- 이 반복의 마지막 출력은 iter_schema.json 형식 JSON이고 iteration 값은 $n 이다.

---

"@
    $body = Get-Content $LoopPrompt -Raw -Encoding utf8
    Set-Content -Path $promptFile -Value ($header + $body) -Encoding utf8

    $stub = "Read the file $promptFile from beginning to end with your file tools and follow it exactly. It is your complete instruction for this run (written in Korean). Before acting, also read the files it tells you to read. Your final message must be the single JSON object required by the output schema."
    $cwd = if (Test-Path (Join-Path $Repo '.git')) { $Repo } else { 'C:\dev' }
    $cargs = @('exec', '--skip-git-repo-check', '-s', $Sandbox, '-C', $cwd, '--json',
        '--output-schema', $Schema, '-o', $lastFile, '-c', 'approval_policy=never')
    if ($Model) { $cargs += @('-m', $Model) }
    if ($Effort) { $cargs += @('-c', "model_reasoning_effort=$Effort") }
    $cargs += $stub
    $argLine = ($cargs | ForEach-Object { Quote-Arg $_ }) -join ' '

    if ($DryRun) {
        Write-Log "DRYRUN $stamp 명령: $Cx $argLine"
        Write-Log "DRYRUN 프롬프트 파일 $promptFile ($((Get-Item $promptFile).Length) B)"
        break
    }

    Write-Log "$stamp 시작 (남은 $left 분)"
    $t0 = Get-Date
    $p = Start-Process -FilePath $Cx -ArgumentList $argLine -NoNewWindow -PassThru `
        -RedirectStandardInput $Empty -RedirectStandardOutput $jsonl -RedirectStandardError $errFile
    $limitMs = [Math]::Min($IterTimeoutMin, [Math]::Max(10, $left)) * 60000
    $finished = $p.WaitForExit($limitMs)
    if (-not $finished) {
        Write-Log "$stamp 시간 상한 초과. 강제 종료"
        & taskkill /PID $p.Id /T /F 2>&1 | Out-Null
        Start-Sleep -Seconds 5
    }
    $mins = [Math]::Round(((Get-Date) - $t0).TotalMinutes, 1)

    $usage = $false
    $retryAt = $null
    if (Test-Path $jsonl) {
        $hit = Select-String -Path $jsonl -Pattern 'usage_limit_exceeded|hit your usage limit|usageLimitExceeded' -List
        if ($hit) {
            $usage = $true
            $m = Select-String -Path $jsonl -Pattern 'try again at ([^"\\]+?)[\.\\"]' | Select-Object -First 1
            if ($m) {
                $txt = $m.Matches[0].Groups[1].Value.Trim()
                $clean = $txt -replace '(\d)(st|nd|rd|th)', '$1'
                $parsed = [DateTime]::MinValue
                if ([DateTime]::TryParse($clean, [ref]$parsed)) { $retryAt = $parsed }
                Write-Log "$stamp 사용 한도: '$txt'"
            }
        }
    }

    if ($usage) {
        $n -= 1
        $calls -= 1
        Remove-Item $promptFile -ErrorAction SilentlyContinue
        $wake = if ($retryAt -and $retryAt -gt (Get-Date)) { $retryAt.AddMinutes(2) } else { (Get-Date).AddMinutes(30) }
        $wakeKst = [System.TimeZoneInfo]::ConvertTime($wake, $Kst)
        if ($wakeKst -ge $DeadlineKst.AddMinutes(-20)) { Write-Log '사용 한도가 마감 전에 안 풀린다. 끝낸다'; break }
        Write-Log ("사용 한도. {0} KST까지 기다린다" -f $wakeKst.ToString('MM-dd HH:mm'))
        while ((Get-Date) -lt $wake -and -not (Test-Path $StopFile)) { Start-Sleep -Seconds 60 }
        continue
    }

    $status = 'noresult'
    $task = '?'
    if (Test-Path $lastFile) {
        try {
            $j = Get-Content $lastFile -Raw -Encoding utf8 | ConvertFrom-Json
            $status = $j.status
            $task = $j.task_id
            $lastSummary = '{0}: status={1} task={2} next={3} | {4}' -f $stamp, $j.status, $j.task_id, $j.next_task, $j.summary
        } catch { $status = 'badjson' }
    }
    $line = '{0} {1} rc={2} mins={3} status={4} task={5}' -f (Now-Kst).ToString('MM-dd HH:mm'), $stamp, $p.ExitCode, $mins, $status, $task
    Add-Content -Path $RunsLog -Value $line -Encoding utf8
    Write-Log $line

    $g2 = Invoke-Guard
    if ($g2.rc -eq 2) {
        Write-Log "반복 뒤 보호 경로 위반. 루프를 멈춘다`n$($g2.text)"
        Set-Content -Path $StopFile -Value ("guard fail after $stamp " + (Now-Kst).ToString('s')) -Encoding utf8
        break
    }

    switch ($status) {
        'all_done' { Write-Log '모든 과제 끝'; $failStreak = 0; break }
        'wait' { $failStreak = 0; $blockStreak = 0; Write-Log "측정 대기. $IdleSleepMin 분 쉰다"; Start-Sleep -Seconds ($IdleSleepMin * 60) }
        'blocked' { $blockStreak += 1; $failStreak = 0 }
        { $_ -in @('done', 'partial') } { $failStreak = 0; $blockStreak = 0 }
        default { $failStreak += 1; Write-Log "결과 없음/실패 연속 $failStreak 번. 5분 쉰다"; Start-Sleep -Seconds 300 }
    }
    if ($status -eq 'all_done') { break }
    if ($blockStreak -ge 3) { Write-Log '막힘 3번 연속. 멈춘다(state/JOURNAL.md 확인)'; break }
    if ($failStreak -ge 3) { Write-Log '실패 3번 연속. 멈춘다(runs/ 의 jsonl, stderr 확인)'; break }
}

Write-Log ('실행기 끝. 이번 실행 호출 {0}번' -f $calls)
