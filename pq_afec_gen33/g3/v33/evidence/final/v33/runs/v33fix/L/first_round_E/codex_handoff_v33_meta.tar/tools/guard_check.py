import argparse
import datetime as dt
import hashlib
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8")

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATE = os.path.join(BASE, "state")
BASELINE = os.path.join(STATE, "guard_baseline.json")
FAIL = os.path.join(STATE, "GUARD_FAIL.txt")
KST = dt.timezone(dt.timedelta(hours=9))

STRICT_TREES = [
    r"C:\dev\pq_afec",
    r"C:\dev\pq_afec_gen3",
    r"C:\dev\pq_afec_gen31",
    r"C:\dev\pq_afec_gen32",
    r"C:\dev\pq_afec_next",
]
WARN_TREES = [r"C:\dev\claude_brain"]
WARN_SKIP_DIRS = {".obsidian", ".trash"}
REPO = r"C:\dev\R-E"
WSL_FILES = [
    "/home/scien/quicbed/bin/qamp",
    "/home/scien/quicbed/bin/qamp.srcsha",
    "/home/scien/quicbed_g3c/bin/qamp",
    "/home/scien/quicbed_g3c/bin/qamp.srcsha",
    "/home/scien/quicbed_gen32/bin/qamp",
]


def snapshot(root, skip_dirs=()):
    out = {}
    if not os.path.isdir(root):
        return None
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in skip_dirs and d != ".git"]
        for name in filenames:
            p = os.path.join(dirpath, name)
            try:
                st = os.stat(p)
            except OSError:
                continue
            out[os.path.relpath(p, root)] = [st.st_size, st.st_mtime_ns]
    return out


def git(*args):
    r = subprocess.run(["git", "-C", REPO] + list(args), capture_output=True,
                       text=True, encoding="utf-8", errors="replace")
    return r.returncode, r.stdout.strip()


def repo_state():
    _, head = git("rev-parse", "HEAD")
    _, branch = git("rev-parse", "--abbrev-ref", "HEAD")
    _, status = git("status", "--porcelain", "--untracked-files=all")
    return {"head": head, "branch": branch, "status": status}


def wsl_hashes():
    cmd = "for f in %s; do if [ -e \"$f\" ]; then sha256sum \"$f\"; else echo \"MISSING $f\"; fi; done" % " ".join(WSL_FILES)
    try:
        r = subprocess.run(["wsl", "-d", "Ubuntu", "--exec", "bash", "-c", cmd],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=120)
    except Exception as e:
        return {"error": repr(e)}
    if r.returncode != 0:
        return {"error": "rc=%d %s" % (r.returncode, r.stderr.strip()[:300])}
    out = {}
    for line in r.stdout.splitlines():
        parts = line.split()
        if len(parts) == 2 and parts[0] == "MISSING":
            out[parts[1]] = "MISSING"
        elif len(parts) == 2:
            out[parts[1]] = parts[0]
    if len(out) != len(WSL_FILES):
        return {"error": "해시 %d/%d개만 읽음: %s" % (len(out), len(WSL_FILES), r.stdout[:300])}
    return out


def collect():
    return {
        "taken_kst": dt.datetime.now(KST).isoformat(timespec="seconds"),
        "strict": {r: snapshot(r) for r in STRICT_TREES},
        "warn": {r: snapshot(r, WARN_SKIP_DIRS) for r in WARN_TREES},
        "repo": repo_state(),
        "wsl": wsl_hashes(),
    }


def diff_tree(old, new, limit=20):
    if old is None and new is None:
        return []
    if old is None or new is None:
        return ["트리 존재 여부가 바뀜"]
    msgs = []
    for k in sorted(set(old) | set(new)):
        if k not in new:
            msgs.append("삭제 " + k)
        elif k not in old:
            msgs.append("생김 " + k)
        elif old[k] != new[k]:
            msgs.append("바뀜 " + k)
        if len(msgs) >= limit:
            msgs.append("…")
            break
    return msgs


def check():
    if not os.path.exists(BASELINE):
        print("NO_BASELINE")
        return 3
    base = json.load(open(BASELINE, encoding="utf-8"))
    now = collect()
    violations = []
    warnings = []
    for root in STRICT_TREES:
        for m in diff_tree(base["strict"].get(root), now["strict"].get(root)):
            violations.append("%s: %s" % (root, m))
    for root in WARN_TREES:
        for m in diff_tree(base["warn"].get(root), now["warn"].get(root)):
            warnings.append("%s: %s" % (root, m))
    b, n = base["repo"], now["repo"]
    if b["head"] != n["head"] or b["branch"] != n["branch"]:
        violations.append("R-E main 작업 트리 HEAD/브랜치가 바뀜: %s %s -> %s %s" % (
            b["branch"], b["head"][:12], n["branch"], n["head"][:12]))
    if b["status"] != n["status"]:
        violations.append("R-E main 작업 트리 상태가 바뀜:\n" + n["status"][:2000])
    bw, nw = base["wsl"], now["wsl"]
    if "error" in nw:
        warnings.append("WSL 해시를 못 읽음: " + nw["error"])
    elif "error" not in bw:
        for f in WSL_FILES:
            if bw.get(f) != nw.get(f):
                violations.append("WSL 보호 파일이 바뀜: %s %s -> %s" % (f, bw.get(f), nw.get(f)))
    stamp = now["taken_kst"]
    if violations:
        with open(FAIL, "w", encoding="utf-8") as fh:
            fh.write("보호 경로 위반 %s\n" % stamp)
            fh.write("\n".join(violations) + "\n")
            if warnings:
                fh.write("\n경고\n" + "\n".join(warnings) + "\n")
        print("GUARD_FAIL")
        for v in violations[:40]:
            print(" -", v)
        return 2
    print("GUARD_OK %s" % stamp)
    for w in warnings[:20]:
        print(" warn:", w)
    return 0


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--init", action="store_true")
    g.add_argument("--check", action="store_true")
    a = ap.parse_args()
    if a.init:
        os.makedirs(STATE, exist_ok=True)
        snap = collect()
        with open(BASELINE, "w", encoding="utf-8") as fh:
            json.dump(snap, fh, ensure_ascii=False)
        counts = {r: (len(v) if v else 0) for r, v in snap["strict"].items()}
        print("BASELINE_WRITTEN", counts, "repo", snap["repo"]["branch"], snap["repo"]["head"][:12],
              "status_lines", len(snap["repo"]["status"].splitlines()), "wsl", snap["wsl"])
        sys.exit(0)
    sys.exit(check())


if __name__ == "__main__":
    main()
