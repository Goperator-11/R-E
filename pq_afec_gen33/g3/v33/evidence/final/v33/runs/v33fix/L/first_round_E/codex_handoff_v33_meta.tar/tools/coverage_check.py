import os
import re
import sys

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8")

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TASKS_MD = os.path.join(BASE, "prompt", "TASKS.md")
INDEX = os.path.join(BASE, "findings", "FINDINGS_INDEX.md")
EXTRA = os.path.join(BASE, "findings", "EXTRA_SOURCES.md")
TASK_ID = re.compile(r"(?<![A-Za-z0-9])([A-Z][0-9])(?![0-9])")


def cards():
    text = open(TASKS_MD, encoding="utf-8").read()
    parts = re.split(r"^### ([A-Z][0-9]) ", text, flags=re.M)
    out = {}
    for i in range(1, len(parts), 2):
        out[parts[i]] = parts[i + 1]
    return out


def index_rows():
    rows = []
    for line in open(INDEX, encoding="utf-8"):
        if not line.startswith("| A"):
            continue
        cols = [c.strip() for c in line.strip().strip("|").split("|")]
        fid = cols[0]
        task = cols[5] if len(cols) >= 7 else cols[3]
        rows.append((fid, task))
    for line in open(EXTRA, encoding="utf-8"):
        if not line.startswith("| Q-"):
            continue
        cols = [c.strip() for c in line.strip().strip("|").split("|")]
        rows.append((cols[0], cols[4]))
    return rows


def by_task(task):
    return [fid for fid, t in index_rows() if task in TASK_ID.findall(t)]


def main():
    if len(sys.argv) == 3 and sys.argv[1] == "--task":
        ids = by_task(sys.argv[2])
        print("%s 과제에 연결된 감사 항목 %d개: %s" % (sys.argv[2], len(ids), ", ".join(ids)))
        return
    cs = cards()
    gaps = []
    rows = index_rows()
    for fid, task in rows:
        tids = TASK_ID.findall(task)
        if not tids:
            gaps.append((fid, task, "과제 번호 없음"))
            continue
        pat = re.compile(r"(?<![\w-])" + re.escape(fid) + r"(?![\w])")
        if not [t for t in tids if t in cs and pat.search(cs[t])]:
            gaps.append((fid, task, "카드 근거에 번호 없음"))
    print("항목", len(rows), "누락", len(gaps))
    for g in gaps:
        print(" ", g)


if __name__ == "__main__":
    main()
