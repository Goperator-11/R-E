"""Offline p3/p4 sample adequacy audit using frozen inputs and the standard library.

No experiment modules are imported. No bootstrap is rerun. Output is descriptive
and exploratory, never an instruction to increase N or a confirmatory power plan.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone, timedelta
import hashlib
import json
import math
from pathlib import Path
import statistics

HERE = Path(__file__).resolve().parent
KST = timezone(timedelta(hours=9))
ARMS = ("off", "on1", "on2")
CONDITIONS = ((1, 1), (2, 1), (5, 1), (2, 3), (5, 3))


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_verified(root):
    provenance = json.loads((root / "provenance.json").read_text(encoding="utf-8"))
    for name, info in provenance["files"].items():
        if sha256(root / info["snapshot_path"]) != info["sha256"]:
            raise ValueError(f"Snapshot SHA256 mismatch: {name}")
    return (json.loads((root / "raw/p3_effect.json").read_text(encoding="utf-8")),
            json.loads((root / "raw/p4_model.json").read_text(encoding="utf-8")),
            provenance)


def arm_stats(run, requested_n):
    samples = run.get("samples") or []
    if not samples or any(not isinstance(x, (int, float)) or isinstance(x, bool)
                          or not math.isfinite(x) or x < 0 for x in samples):
        raise ValueError("Empty, negative or non-finite latency samples")
    n, ok, fail = run["n"], run["ok"], run["fail"]
    if n != requested_n or n != ok + fail or ok != len(samples):
        raise ValueError("Attempt/success/failure/sample counts disagree")
    mean = statistics.mean(samples)
    if not math.isclose(mean, run["mean"], rel_tol=1e-12, abs_tol=1e-9):
        raise ValueError("Stored mean differs from successful samples")
    variance = statistics.variance(samples) if len(samples) >= 2 else None
    return {"attempted_n": n, "successful_n": ok, "failed_n": fail,
            "success_rate": ok / n, "mean_success_ms": mean,
            "variance_success_ms2": variance,
            "se_success_ms": math.sqrt(variance / ok) if variance is not None else None,
            "pto_rate_among_successes": run.get("pto_rate"),
            "max_success_ms": max(samples), "valid": bool(run.get("valid"))}


def legacy_need(first_samples, second_samples, stored_gap):
    """Reproduce the existing p4 arithmetic including 1.96 and truncation."""
    def se(values):
        if len(values) < 2:
            return None
        mean = sum(values) / len(values)
        return (sum((x - mean) ** 2 for x in values)
                / (len(values) - 1) / len(values)) ** 0.5
    a, b = se(first_samples), se(second_samples)
    if not a or not b or stored_gap <= 0:
        return None
    return int(len(first_samples) * (1.96 * math.sqrt(a*a + b*b) / stored_gap) ** 2)


def resolution_sensitivity(first, second, gap, alpha, env_floor):
    """IID, fixed-allocation, observed-effect normal CI-width sensitivity only."""
    if not 0 < alpha < 1:
        raise ValueError("alpha must be between zero and one")
    z = statistics.NormalDist().inv_cdf(1 - alpha / 2)
    result = {"alpha": alpha, "normal_z": z,
              "gap_below_observed_env_floor": gap < env_floor,
              "n_reference": None, "n_second": None, "scale": None,
              "target_power": None, "confirmatory_plan": False,
              "guarantees_p4_decision": False}
    variance1 = first["variance_success_ms2"]
    variance2 = second["variance_success_ms2"]
    if gap <= 0:
        result["unavailable_reason"] = "Observed gap is zero; no finite width target"
        return result
    if variance1 is None or variance2 is None or variance1 + variance2 <= 0:
        result["unavailable_reason"] = "Insufficient or degenerate variance estimate"
        return result
    se = math.sqrt(variance1 / first["successful_n"] + variance2 / second["successful_n"])
    scale = (z * se / gap) ** 2
    result.update({"se_difference_ms": se, "scale": scale,
                   "n_reference": math.ceil(first["successful_n"] * scale),
                   "n_second": math.ceil(second["successful_n"] * scale),
                   "unavailable_reason": None})
    return result


def audit(p3, p4, provenance):
    n = p3["n"]
    alpha = p4["multiple_comparison"]["alpha"]
    groups = list(p4["env_floor_ms"])
    def key(row):
        return row["group"], row["loss"], row["burst"]
    records = {}
    for kind in ("policy_check", "policy_skipped"):
        for row in p4[kind]:
            if key(row) in records:
                raise ValueError("Duplicate p4 policy condition")
            records[key(row)] = kind, row
    runs = {}
    for run in p3["runs"]:
        rk = (*key(run), run["dir"], run["arm"])
        if rk in runs:
            raise ValueError("Duplicate p3 run")
        runs[rk] = run
    rows = []
    all_arm_rows = []
    for group in groups:
        controls = [runs[(group, 0, 1, "c2s", arm)] for arm in ARMS]
        for control in controls:
            arm_stats(control, n)
            if not control["valid"]:
                raise ValueError("Invalid zero-loss control")
        env = max(r["mean"] for r in controls) - min(r["mean"] for r in controls)
        if not math.isclose(env, p4["env_floor_ms"][group], abs_tol=1e-12):
            raise ValueError("Environment floor mismatch")
        for loss, burst in CONDITIONS:
            kind, recorded = records[(group, loss, burst)]
            arms, originals = {}, {}
            for arm in ARMS:
                run = runs[(group, loss, burst, "c2s", arm)]
                arms[arm] = arm_stats(run, n)
                originals[arm] = run
                if not run["valid"]:
                    raise ValueError("Invalid condition unexpectedly used in p4")
                if not math.isclose(run["mean"], recorded["means"][arm], abs_tol=1e-9):
                    raise ValueError("p3 and p4 means disagree")
                all_arm_rows.append({"group": group, "loss_pct": loss,
                                     "burst": burst, "arm": arm, **arms[arm]})
            order = sorted(recorded["means"], key=recorded["means"].get)
            first, second = order[:2]
            gap = recorded["means"][second] - recorded["means"][first]
            old = legacy_need(originals[first]["samples"], originals[second]["samples"], gap)
            skipped = kind == "policy_skipped"
            if skipped and old != recorded.get("n_needed"):
                raise ValueError("Legacy N is not reproduced")
            retained = list(recorded.get("tie_set", []))
            if skipped and recorded.get("why") == "전 팔이 잡음 동률":
                retained = sorted(arms)
            rows.append({"group": group, "loss_pct": loss, "burst": burst, "direction": "c2s",
                         "p4_record_kind": kind,
                         "policy_status": "판정불능" if skipped else "판정대상",
                         "policy_arm_recorded": recorded.get("policy", recorded.get("want")),
                         "policy_in_retained_set_recorded": recorded.get("agree"),
                         "stored_reason": recorded.get("why"),
                         "retained_set": retained,
                         "equivalence_assessed": False, "equivalence_conclusion": "동등성 미검증",
                         "observed_best_arm": first, "observed_second_arm": second,
                         "observed_top_two_gap_ms": gap, "env_floor_ms": env,
                         "arms": arms,
                         "stored_n_needed": recorded.get("n_needed"),
                         "legacy_n_recomputed_if_skipped": old if skipped else None,
                         "legacy_n_matches": old == recorded.get("n_needed") if skipped else None,
                         "iid_normal_resolution_sensitivity": resolution_sensitivity(
                             arms[first], arms[second], gap, alpha, env)})
    if len(records) != len(rows):
        raise ValueError("Unexpected policy conditions")
    eligible = [r for r in rows if r["policy_status"] == "판정대상"]
    agreement = [sum(r["policy_in_retained_set_recorded"] is True for r in eligible), len(eligible)]
    if agreement != p4["policy_agreement"]:
        raise ValueError("Policy agreement denominator mismatch")
    return {"schema_version": 1, "analysis_kind": "offline_exploratory_sample_adequacy",
            "provenance": provenance, "analysis_script_sha256": sha256(Path(__file__)),
            "summary": {"attempted_n_per_arm": n, "policy_conditions_total": len(rows),
                        "policy_conditions_evaluable": len(eligible),
                        "policy_conditions_inconclusive": len(rows) - len(eligible),
                        "policy_agreement_conditional": agreement,
                        "p4_gate_passed": p4["passed"], "p4_gate_total": p4["total"],
                        "failed_connections_in_policy_conditions": sum(r["failed_n"] for r in all_arm_rows),
                        "successful_connections_in_policy_conditions": sum(r["successful_n"] for r in all_arm_rows),
                        "policy_conditions_with_equivalence_test": 0,
                        "multiple_comparison_recorded": p4["multiple_comparison"],
                        "original_bootstrap_reexecuted": False,
                        "automatic_expansion_or_experiments": False},
            "interpretation": {
                "estimand": "Mean HCT conditional on successful connections; failures retained separately",
                "retained_set": "Arms not excluded by the existing bootstrap-or-environment-floor rule; not equivalence",
                "legacy_n": "Post-hoc normal CI-width proxy using z=1.96, not the recorded alpha=0.005; truncates",
                "sensitivity_formula": "SE=sqrt(s1^2/n1+s2^2/n2); scale=(z_(1-alpha/2)*SE/gap)^2; n1_new=ceil(n1*scale), n2_new=ceil(n2*scale)",
                "n_unit": "Successful observations in the currently best arm and second arm at fixed allocation ratio; total target counts, not additional attempts",
                "assumptions": ["Independent identically distributed successful samples within and between arms",
                                "Current variances, observed gap and allocation ratio persist",
                                "Normal approximation, with no power target",
                                "Best and second arm selected from the same data; effect not prespecified"],
                "limitations": ["No formal sample sufficiency conclusion or confirmatory sample plan",
                                "No serial correlation or between-run drift correction",
                                "Top-two separation does not equal the p4 not-all-arms-retained criterion",
                                "A gap below the observed environment floor stays retained if that floor and gap remain fixed, regardless of N",
                                "Matching alpha in a normal approximation does not reproduce the bootstrap decision or certify familywise error control",
                                "Original 2000-resample decisions reused; tail counts and confidence intervals were not saved in p4"],
                "equivalence": {"tested": False, "prespecified_margin": None, "conclusion": "동등성 미검증"}},
            "conditions": rows, "arm_details": all_arm_rows}


def export(result, dest):
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "sample_size_audit.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    flat = []
    for row in result["conditions"]:
        s = row["iid_normal_resolution_sensitivity"]
        a, b = row["observed_best_arm"], row["observed_second_arm"]
        flat.append({"group": row["group"], "loss_pct": row["loss_pct"], "burst": row["burst"],
                     "status": row["policy_status"], "best": a, "second": b,
                     "gap_ms": row["observed_top_two_gap_ms"], "env_floor_ms": row["env_floor_ms"],
                     "gap_below_floor": s["gap_below_observed_env_floor"],
                     "current_success_n_best": row["arms"][a]["successful_n"],
                     "current_success_n_second": row["arms"][b]["successful_n"],
                     "failed_connections_all_arms": sum(x["failed_n"] for x in row["arms"].values()),
                     "stored_n_needed": row["stored_n_needed"],
                     "legacy_n_recomputed": row["legacy_n_recomputed_if_skipped"],
                     "normal_alpha": s["alpha"], "normal_z": s["normal_z"],
                     "exploratory_n_best": s["n_reference"], "exploratory_n_second": s["n_second"],
                     "target_power": "unspecified", "confirmatory_plan": False,
                     "equivalence": row["equivalence_conclusion"],
                     "retained_set": ";".join(row["retained_set"]),
                     "policy_recorded": row["policy_arm_recorded"]})
    for name, rows in (("sample_size_conditions.csv", flat), ("sample_size_arms.csv", result["arm_details"])):
        with (dest / name).open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot-dir", type=Path, default=HERE)
    parser.add_argument("--output-dir", type=Path, default=HERE / "derived")
    args = parser.parse_args()
    result = audit(*load_verified(args.snapshot_dir))
    export(result, args.output_dir)
    print(json.dumps(result["summary"], ensure_ascii=False, indent=2))
    for row in result["conditions"]:
        if row["policy_status"] == "판정불능":
            print(row["group"], row["loss_pct"], row["burst"], row["stored_n_needed"],
                  row["iid_normal_resolution_sensitivity"]["n_reference"],
                  row["iid_normal_resolution_sensitivity"]["n_second"])


if __name__ == "__main__":
    main()
