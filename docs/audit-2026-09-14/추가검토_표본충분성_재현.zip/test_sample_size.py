"""Small scientific regression checks on frozen data and analytic edge cases."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import summarize_sample_size as S


class SampleAdequacyTests(unittest.TestCase):
    def test_known_normal_resolution_and_stricter_alpha(self):
        a = {"variance_success_ms2": 1, "successful_n": 2}
        loose = S.resolution_sensitivity(a, a, 1, .05, 0)
        strict = S.resolution_sensitivity(a, a, 1, .005, 0)
        self.assertEqual(loose["n_reference"], 8)
        self.assertEqual(strict["n_reference"], 16)
        self.assertIsNone(strict["target_power"])
        self.assertFalse(strict["confirmatory_plan"])

    def test_zero_gap_has_no_finite_n(self):
        a = {"variance_success_ms2": 1, "successful_n": 10}
        value = S.resolution_sensitivity(a, a, 0, .005, .5)
        self.assertIsNone(value["n_reference"])
        self.assertIn("zero", value["unavailable_reason"])

    def test_zero_variance_does_not_claim_zero_observations_sufficient(self):
        a = {"variance_success_ms2": 0, "successful_n": 10}
        self.assertIsNone(S.resolution_sensitivity(a, a, 1, .005, 0)["n_reference"])

    def test_environment_floor_is_kept_separate_from_n(self):
        a = {"variance_success_ms2": 1, "successful_n": 1200}
        r = S.resolution_sensitivity(a, a, .1, .005, .2)
        self.assertTrue(r["gap_below_observed_env_floor"])
        self.assertFalse(r["guarantees_p4_decision"])

    def test_failure_counts_are_not_silently_discarded(self):
        r = {"samples": [1, 3], "n": 3, "ok": 2, "fail": 1,
             "mean": 2, "valid": True}
        self.assertEqual(S.arm_stats(r, 3)["failed_n"], 1)
        r["fail"] = 0
        with self.assertRaises(ValueError):
            S.arm_stats(r, 3)

    def test_frozen_results_reproduce_all_four_legacy_n(self):
        p3, p4, provenance = S.load_verified(S.HERE)
        d = S.audit(p3, p4, provenance)
        rows = [r for r in d["conditions"] if r["policy_status"] == "판정불능"]
        self.assertEqual([r["legacy_n_recomputed_if_skipped"] for r in rows],
                         [117700, 24307, 6226, 3174])
        self.assertTrue(all(r["legacy_n_matches"] for r in rows))
        self.assertEqual(d["summary"]["policy_agreement_conditional"], [6, 6])
        self.assertEqual(d["summary"]["failed_connections_in_policy_conditions"], 3)
        self.assertEqual(d["summary"]["successful_connections_in_policy_conditions"], 35997)
        self.assertTrue(all(not r["equivalence_assessed"] for r in d["conditions"]))
        altered = copy.deepcopy(p4)
        altered["policy_skipped"][0]["n_needed"] += 1
        with self.assertRaises(ValueError):
            S.audit(p3, altered, provenance)

    def test_snapshot_tampering_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "raw").mkdir()
            (root / "raw/p3_effect.json").write_text("{}", encoding="utf-8")
            (root / "provenance.json").write_text(json.dumps({"files": {
                "p3_effect.json": {"snapshot_path": "raw/p3_effect.json", "sha256": "0" * 64}
            }}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "SHA256"):
                S.load_verified(root)


if __name__ == "__main__":
    unittest.main(verbosity=2)
