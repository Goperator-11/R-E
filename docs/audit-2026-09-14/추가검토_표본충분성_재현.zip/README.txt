Offline audit. Python standard library only.
Run: python -B summarize_sample_size.py
Then: python -B test_sample_size.py
Do not run source_snapshot scripts: they are evidence only.
N values are exploratory, post-hoc CI-width sensitivities, not a confirmatory plan.
